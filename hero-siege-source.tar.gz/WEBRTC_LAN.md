# WebRTC / LAN multiplayer

Rollback: see ROLLBACK.md (stable Sites v164).

In Multiplayer, the creator selects **WebRTC / LAN · host on this device** and creates a room. Guests join normally using its code; the room chooses their connection mode. The host chooses a hero and starts once everyone has chosen. The host's browser simulates all heroes and units. Guests send input only. The lobby server authenticates room membership and exchanges offers, answers and ICE candidates. Direct reliable data channels carry inputs and chunked snapshots; server WebSocket relay is a fallback if direct LAN connections fail. The arena status distinguishes direct connections from relay. No camera/microphone permissions, no TURN service, no external STUN dependency (host ICE candidates preferred for same-LAN use).

The host must keep the game tab visible and screen awake. A screen wake lock is requested where supported. Background suspension can pause the match. Leaving or losing the signaling connection ends the session; host migration/reconnection is not implemented. This is not offline phone-to-phone discovery: internet access is still needed for the hosted lobby/signaling service. It does not automatically discover nearby rooms or guarantee a direct path on guest Wi-Fi with device isolation.

## Without internet, using a local lobby server

On a computer on the same router, run `npm ci` then `npm start`. Open `http://<computer-LAN-IP>:10000` on each device. The server binds to 0.0.0.0; its dynamic multiplayer configuration selects the same local server. The phone creating the room can still be the simulation host in WebRTC mode; the computer only handles lobby/signaling/relay. Use a browser that supports WebRTC data channels on the served origin; where local HTTP WebRTC is restricted, use Online server mode on that LAN address or a trusted HTTPS deployment. Do not bypass certificate warnings.

## Deployment

Both frontend and server changes are required. Sites frontend preserves Online server mode with the older Render server. A WebRTC create attempt against an old lobby returns a clear update-required message and closes its temporary room. Updating GitHub/Render remains a separate user-authorized operation.

## Validation

Node tests cover existing authoritative online matches plus WebRTC room creation, signaling routing, host-only state relay, rejection of guest state injection and session cleanup. Browser QA uses two local clients to check lobby, host simulation, guest state and input. Cross-device physical Wi-Fi behavior still requires a real-device test; cloud-browser networking may force relay.
