# Multiplayer deployment

GitHub repository: https://github.com/vypur85/hero-siege
Render service: srv-dbg8dsh42hec73dtdd4g
Render workspace: tea-dbddhh1srm7s73bcfo7g (Hong Vee)
Endpoint: https://hero-siege-multiplayer.onrender.com
Source commit deployed initially: 8acac44813df75fbc75acd7286fbe9c7f1b8dad5

The public GitHub repository holds the complete source in hero-siege-source.tar.gz, uploaded through the GitHub website because the connector returned a write-permission error. Render extracts it in its build command, then installs pinned npm dependencies. The static Sites frontend reads dist/multiplayer-config.json. The Render-hosted frontend discovers its own endpoint from /multiplayer-config.json.

Use the free Node web service in Singapore; no database or secrets. The initial server-authoritative room implementation supports up to four players. Disconnection ends a running session; no persistence or reconnection is claimed.
