# Hero Siege art direction

All new or revised artwork, ability effects, and icons should match the established Kingdom Rush-inspired hand-painted fantasy cartoon style: bold inked contours, chunky readable silhouettes, painted shading, and expressive shapes. Match the existing portraits, overhead units, and painted arena.

Paladin ability icons and effects use blue as their primary colour, with navy outlines, cobalt midtones, and icy cyan highlights. Stomp is an explicit exception: its ground effect uses only black branching cracks on transparency, stays fixed in place, and only fades; no coloured ground fill. Its icon retains the blue Paladin theme. Keep gameplay dimensions and timings accurate.

All arena hero and creep units remain true overhead views. Ground effects respect that camera. Item and player labels remain legible.

# Ability description standard

Describe gameplay only: activation or target type, damage, healing, stat bonuses, range or area, duration, cooldown, and relevant targeting rules. Omit visual and animation details such as colour, glow, model size, spinning, start angle, art design, and fade timing. Apply this to all future hero abilities and revised descriptions.

# Allied structures

Castle at arena center: 4-unit diameter, 30000 HP, stationary, no attack. Four cardinal arrow towers: 1.5-unit diameter, 0.5-unit edge gap to castle, 10000 HP, 3000 damage, 6-unit acquisition range, base 0.8 seconds between homing normal attacks. Structures belong to the players team; players cannot control or attack them. Use overhead painted medieval art.

# Collision and movement

All living heroes, creeps, and buildings have circular collision footprints: radius equals half their declared unit diameter. Heroes/creeps default to 1 unit, castle 4 units, towers 1.5 units. Movement must sweep against all living bodies and route around blocked paths; never move fixed buildings or push stunned units. Narrow gaps must fit the full moving diameter. Dead units do not block. Resolve spawn overlaps in free space while preserving building positions. Keep the melee aggro leash during automatic routing.

# Bounty ownership

Bounty text belongs to the killing unit's player and is rendered only for that player. Castle and towers belong to a separate neutral player allied with human players; their kills cannot give human players gold or XP, and their bounty text must not appear for human players.

# Arena terrain layout

Follow the user sketch: round central clearing, four diagonal lanes to circular corner pads, four cardinal shop alcoves. Raised rocky forest outside the walkable union is impassable. Terrain rendering and pathfinding share the same analytic map; full collision footprints and swept movement must remain walkable.

Four enemy Spires on corner pads: purple tentacle/spike theme, 3-unit diameter, 50000 HP, 100HP/s regeneration, 10000 damage, 6-unit range, 0.65 seconds per homing purple goo attack. Allied with creeps, hostile to player allies, stationary and uncontrollable.

Four neutral Elf shops in cardinal alcoves: mossy elven wooden hut, 2-unit diameter,100HP, invulnerable and excluded from attack targets, stationary and uncontrollable.

Clicks on impassable terrain issue a movement command to the nearest free walkable destination, with full unit-radius clearance. Show the destination marker there and route through walkable ground; do not ignore the click or allow crossing high ground.

# Overhead unit bars

Every living arena unit has an overhead HP bar except Elf shops. Allied and friendly neutral HP bars are green; enemy HP bars are red. Heroes additionally have a blue mana bar directly beneath the HP bar, with their player name above the bars. Use a shared renderer for heroes, creeps, and structures; no old bars below units.

Spire ground ornament: stationary purple medieval ring, 2-unit diameter, centered along the direction from each Spire into its lane toward the central clearing. Leave a1-unit clear gap between the Spire perimeter and ring perimeter. Purely visual, no collision or damage.

# Creep waves and death effects

No test creeps or individual creep respawns. Spawn rings are clockwise:1top-left,2top-right,3bottom-right,4bottom-left. Activate the first N rings for N human players, excluding neutral ownership; a dead player still counts. Each active living-Spire ring runs a repeating10-second visible countdown, then spawns2melee and1ranged creep wholly inside its circle. If occupied, wait for space; never overlap units. Creeps advance toward the castle and engage opponents within6units along the route. Destroying a Spire disables its spawn ring.

Creep bodies/art are70% of their previous size; ranged normal attack range is6units. Keep existing creep HP and bounty values. Unit deaths leave stationary red(player side) or purple(enemy side) splatters fading over1second. Destroyed buildings leave persistent material-matched ruins: purple Spire fragments, white masonry for arrow towers, white masonry and blue roof fragments for castle. Corpses do not block movement.

# Current hero testing setup

Selected heroes start at level1 with standard starting stats, one skill point, and all abilities unlearned. Heroes have temporary testing damage immunity. They remain valid enemy attack targets; this is separate from Elf shop invulnerability/untargetability. Normal XP and leveling remain enabled.

Creep stats: melee 450 max HP and random integer 20–22 normal attack damage; ranged 300 max HP and random integer 15–17 normal attack damage. Roll once per attack (at launch for ranged projectiles). Supersedes prior test creep HP.

All four diagonal lanes are 50% wider: radius 48 logical pixels (96px width, 6 units), formerly radius 32 (64px width). Rendered terrain mask and movement collision share terrainLayout.laneRadius. Central clearing, corner pads and structures retain their positions and sizes.

Elf shop: every hero starts with 1000 gold. Click a shop when the hero is within 2 units of edge-to-edge distance to open a CP-confined shop drawer; it closes outside range. Square painted item buttons are grey/disabled when unaffordable or inventory is full. Purchase validates proximity, own gold and free slot; equips independent item instance. Health potion costs 100 gold, has 20 charges, heals 1000 HP capped at max on short click, decrements charge shown bottom right, removes at zero; bright expanding green glow fades over 1 second. Hold still shows description; hold-drag preserves remaining charges when reordered or dropped. Broadsword now gives +100 damage, costs 1000 gold. Mask of Madness unchanged 50% actual-damage lifesteal, costs 50000 gold. No initial ground items.

All current and future heroes use Q/W/E/R for ability slots 1–4. Active abilities show their uppercase key at top left of the CP icon; passive slots show no shortcut badge and cannot activate by keyboard. Shortcuts use normal activation rules (learned rank, cooldown, life, stun) and repeated keydown, composition, typing fields and Ctrl/Alt/Meta combinations are ignored.

Elf shop eligibility requires a living player-team hero, never creeps or buildings. Each shop shows a bobbing blue downward arrow and “Click me” above it only while the local player hero is in the exact buying zone; hidden immediately outside range or on hero death. Hint uses same shopInRange predicate as opening and purchases.

Charged shop purchases merge into the first identical equipped charged item by item ID, adding the full purchased charge count with no cap. They do not require a free slot, including full inventories. Example: 19 potion charges + purchase of 20 = 39. Gold and proximity checks still apply. Noncharged items continue to require a free slot. Shop affordability/capacity updates follow this rule for future charged items too.

Heroes no longer have test damage immunity. Normal death revive time is 30s. Revive amulet is passive, costs 5000 gold, comes with 5 charges, consumes one on the death transition and sets that death's revival to 5s; disappears at zero. Repeated damage on an already dead hero never consumes extra charges. Shop purchases top up identical equipped amulet charges. Every new hero receives an independent free Revive amulet (slot 1, 5 charges) and Health potion (slot 2, 20 charges), retaining 1000 starting gold and level 1. Equipped item slots show numbers 1–6 at top left and charges bottom right; matching keyboard number uses the current item in the slot with normal life/stun/typing/repeat guards. Passive items cannot be manually used. Paladin Equip Armour still grants its designed temporary damage immunity.

All hero revivals now restore the exact location recorded on death, replacing return to starting coordinates. Revive amulet shortens revival to 3 seconds (formerly 5); normal revival remains 30 seconds.

Every hero revival, normal or amulet-assisted, triggers a golden angelic wing-and-halo ground sigil drawn beneath the hero and fading to zero over 2 seconds. Effect is cosmetic and grants no immunity.

Revival halo now expands smoothly from its original size to double the radius while fading over 3 seconds, replacing the previous fixed 2-second effect.

Balance update: Strongshot cooldown is 15/13/11/9 seconds at ranks 1–4, starting on actual release. Melee creep HP/maxHP 1200, ranged 800. Their attack damage ranges remain 20–22 and 15–17 respectively.

Castle destruction is a shared losing condition for every human player. It immediately sets match defeat, freezes simulation/movement/combat and blocks further commands and purchases. A single “Defeated!” dialog with “Quit Game” appears after a real-time 3000ms delay. Quit returns to hero selection and resets the match, cancelling pending defeat timers. Destroying other structures does not end the match.


## Standing art direction
All new unit models, hero portraits, ability icons, terrain, landscapes and other designed game art should reference Kingdom Rush: original colourful hand-painted cartoon fantasy designs, bold outlines and clear silhouettes.


Snow centaur (2026-10-27): built-in image generation. Asset: dist/assets/snow-centaur.webp. Prompt: Original snow centaur enemy sprite for top-down fantasy tower defense; Kingdom Rush reference for chunky hand-painted cartoon fantasy, readable shapes and dark outlines; white horse body, pale blue torso, frosty mane, ice armour, enormous icy crescent poleaxe; full body facing right, transparent background, no text or scenery.

Snow centaur overhead revision: built-in image generation; dist/assets/snow-centaur-overhead.webp. Prompt: strict orthographic overhead camera looking vertically down at crown, shoulders, horse back and hooves; right-facing original white snow centaur with blue torso, white mane, ice armour and icy sickle; Kingdom Rush inspired hand-painted cartoon fantasy; transparent background, no scenery or text.

Hero selection backdrop: built-in image generation; dist/assets/hero-selection-forest.webp. Prompt: original Kingdom Rush inspired hand-painted fantasy forest and castle courtyard, quiet parchment clearing for UI; ornate carved oak, weathered stone, ivy and amber-gem perimeter with shield corners; no characters, words or buttons.

Main menu siege backdrop: built-in image generation. Asset dist/assets/main-menu-siege.webp. Prompt: original Kingdom Rush inspired hand-painted cartoon castle and arrow towers under siege by creeps and two red dragons; castle and action on right and edges, quiet middle-left for menu, clear upper sky for title; oak/ivy/gold perimeter; no text or interface.

Local-only bright homepage revision (2026-10-27): reference upload 01-1000104123.jpg for saturated cheerful cyan/green palette and chunky rounded bevel lettering. Built-in image generation produced original sunny castle/arrow-tower siege (dist/assets/main-menu-bright-siege.webp) and transparent original gold HERO / coral-red SIEGE title with navy outline and small crown (dist/assets/hero-siege-title-bright.webp). Reference characters and logo were not copied. No publishing authorized.

Title emblem revision: built-in image edit of hero-siege-title-bright.webp; replace crown only with polished blue/gold shield and two crossed silver-tipped spears, retaining exact gold HERO / red SIEGE chunky bevel lettering, navy outline, purple shadow and transparency. Asset dist/assets/hero-siege-title-shield.webp. Publish only to Sites test link; GitHub/Render updates remain unauthorized.

Hero selection bright courtyard: built-in image generation using main-menu-bright-siege.webp as the art-direction reference. Prompt: sunny hero gathering courtyard with cyan sky, vivid grass/teal trees, pale castle with blue roofs and wooden arrow towers, open quiet centre for portraits, leafy/gold/blue-gem border, no characters or text. Asset dist/assets/hero-selection-bright-courtyard.webp. Publish to Sites test link only.

Banner heraldry revision: built-in image edits of the bright homepage siege and hero selection courtyard. Replace every crown emblem on blue cloth banners, pennants and foreground shield decoration with a plain gold heraldic shield silhouette, preserving scenes, colours and lighting. New assets dist/assets/main-menu-bright-shields.webp and dist/assets/hero-selection-bright-shields.webp. Sites test link publication only; no GitHub or Render changes.

Homepage title recolour: white HERO and royal blue SIEGE, preserving shield/crossed-spears cartoon lettering. Imagegen edit source: hero-siege-title-shield.webp; output hero-siege-title-white-blue.webp. Homepage title dimensions enlarged 50%; actions centered beneath.

Paladin Slash: blue crescent swoosh passive icon, chunky painted fantasy tower-defense styling. Generated original asset paladin-slash-blue.webp.


## Version 175 — overhead creep correction
Replaced all 18 `dist/assets/creep-model-1.webp` through `creep-model-18.webp` using built-in image generation, retaining distinct tier 2/3 melee, ranged, flying, dragons and all ten superwave identities. Level 1 and the overhead snow centaur already matched the view and remain. Runtime assets are 256×256 transparent WebP; no gameplay values changed.

Prompt shared by all replacements: one isolated hand-painted cartoon fantasy game sprite, chunky clean dark outlines and bright Kingdom Rush inspired colors. Strict orthographic top-down plan view, camera exactly 90 degrees overhead looking vertically down at the top of head, back, shoulders and wings. Face east/right with weapons forward. No visible chest, standing portrait, side profile, isometric or three-quarter camera. Full centered silhouette with clear margins, transparent background, no scenery, text or cast shadow.

Subjects in numeric order: green orc cleaver infantry; hooded goblin crossbowman; turquoise winged energy imp; red/gold dragon; black iron red-plumed knight; purple skeletal sorcerer; purple gargoyle; dark crimson armored dragon; red-haired dwarf berserker; green ogre bulwark; skeletal gold/black legionnaire; blue frost yeti; red/black chain-flail juggernaut; mossy green rune stone golem; brown tribal minotaur; molten lava cleaver demon; purple spider reaper; gold/black/purple abyssal overlord.
