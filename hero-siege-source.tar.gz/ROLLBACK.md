# Before WebRTC / LAN hosting

Stable rollback: Sites version 164.
Saved version: appgprj_6adcbd5baaac8191a71523a37262bcee~appgver_8c92b589bb808191b6a01bde5027c767
Source commit: 857b248b994400e3418a824bb2a3a84b3d4cf710
Render/GitHub last deployed version: 161, GitHub commit 30e7bd87295b0affb83024b515b3c99aaed40c28.

To roll back the test link, deploy the exact saved Sites version above. No reconstruction needed. GitHub and Render are not changed by the WebRTC implementation unless separately authorized.
