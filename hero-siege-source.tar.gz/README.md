# Hero Siege

A fantasy castle-defence game with singleplayer and server-authoritative cooperative rooms for up to four players.

## Run locally

Use Node.js 22 or later. Run `npm ci`, then `npm start`, and open `http://localhost:10000`.

## Multiplayer

Create a room, share its six-character code, choose a hero, and have the host start. A single server runs the game simulation and sends the same world state to every player. Inputs are bound to each WebSocket connection. Skills, inventory, gold and private warnings belong to individual players. The host controls the testing speed. Current test settings start heroes at level 20 and prevent hero/tower damage.

A disconnected player ends the current session; reconnect by creating a new room. Rooms are temporary and do not survive server restarts. This first version targets small cooperative test sessions on one server instance.

## Hosting

Render: Node web service, Singapore region, `npm ci --omit=dev` build, `npm start` start. `PORT` is supplied by Render; the server binds to `0.0.0.0`. `/health` reports readiness. The deployment serves the frontend and WebSocket endpoint at `/multiplayer`. No database or API key is needed.

The existing Sites frontend may connect to the Render server through `dist/multiplayer-config.json`. `ALLOWED_ORIGINS` can add explicit comma-separated frontend origins. The server's own origin and the current Hero Siege Sites origin are allowed.

## Checks

`npm test` verifies independent hero control, shared world state, private purchases, room joining, hero selection, starting, and host-only commands.
