import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {JSDOM} from 'jsdom';
test('comic intro fades between invasion and hope and only commits the hero after completion or Skip',()=>{
 const html=readFileSync(new URL('../dist/index.html',import.meta.url),'utf8'),dom=new JSDOM('<div id="root"></div>',{runScripts:'outside-only'}),w=dom.window,timers=new Map();let id=0,completed=0;
 try{w.setTimeout=(fn,ms)=>{timers.set(++id,{fn,ms});return id;};w.clearTimeout=id=>timers.delete(id);
 const code=html.slice(html.indexOf('// Comic runs before'),html.indexOf('const heroSelection=root.querySelector'));
 w.eval("const root=document.querySelector('#root'),heroSelection={hidden:false},paladinPortrait='paladin.webp',rangerPortrait='ranger.webp';"+code+";window.play=playSiegeIntro;window.finish=finishSiegeIntro;");
 w.play('orc',()=>completed++);const intro=w.document.querySelector('.siege-intro');assert(!intro.hidden);assert.equal(completed,0);const words=intro.querySelector('p').textContent.trim().split(/\s+/).length;assert(words>=20&&words<=30);assert.equal(intro.querySelectorAll('.active').length,1);
 [...timers.values()].find(t=>t.ms===6500).fn();assert(intro.querySelectorAll('.intro-scene')[1].classList.contains('active'));
 [...timers.values()].find(t=>t.ms===13000).fn();assert(intro.classList.contains('ending'));assert.equal(completed,0);
 [...timers.values()].find(t=>t.ms===15000).fn();assert(intro.hidden);assert.equal(completed,1);assert(w.document.querySelector('.intro-arena-reveal'));const revealTimer=[...timers.entries()].find(([id,t])=>t.ms===1000);revealTimer[1].fn();timers.delete(revealTimer[0]);assert.equal(timers.size,0);w.finish();assert.equal(completed,1);
 w.play('paladin',()=>completed++);intro.querySelector('.intro-skip').click();assert(intro.hidden);assert.equal(completed,2);assert.equal(timers.size,0);
 }finally{w.close();}
});
