import {readFileSync} from 'node:fs';
import {JSDOM,VirtualConsole} from 'jsdom';
const html=readFileSync(new URL('../dist/index.html',import.meta.url),'utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const markup=html.replace(/<style>[\s\S]*?<\/style>/g,'').replace(/<script>[\s\S]*?<\/script>/g,'');
export function createEngine(members){
 const dom=new JSDOM(markup,{url:'http://engine.internal',runScripts:'outside-only',pretendToBeVisual:true,virtualConsole:new VirtualConsole()});
 const w=dom.window;w.__HERO_SIEGE_SERVER__=true;w.requestAnimationFrame=()=>0;w.ResizeObserver=class{observe(){}disconnect(){}};
 const gradient={addColorStop(){}};const noop=()=>{};const ctx=new Proxy({measureText:()=>({width:20}),createLinearGradient:()=>gradient,createRadialGradient:()=>gradient},{get:(t,k)=>t[k]||noop,set:(t,k,v)=>(t[k]=v,true)});
 w.HTMLCanvasElement.prototype.getContext=()=>ctx;
 Object.defineProperty(w.HTMLElement.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?864:1138;}});Object.defineProperty(w.HTMLElement.prototype,'clientHeight',{get(){return 640;}});
 w.eval(script);const game=w.document.querySelector('#hero-siege-preview').multiplayerBridge;game.init(members);
 return {step:dt=>game.step(dt),input:(id,input)=>game.input(id,input),snapshot:()=>game.snapshot(),notices:()=>game.notices(),close(){game.close();w.close();},testing:w.document.querySelector('#hero-siege-preview').arenaTest};
}
