import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes,randomUUID} from 'node:crypto';
import {WebSocketServer,WebSocket} from 'ws';
import {createEngine} from './engine.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'../dist');
const types={'.html':'text/html; charset=utf-8','.js':'application/javascript','.json':'application/json','.webp':'image/webp','.png':'image/png','.otf':'font/otf','.woff2':'font/woff2'};
export function createGameServer(){
 const rooms=new Map();let closing=false;
 const server=http.createServer(async(req,res)=>{
  const path=new URL(req.url,'http://local').pathname;
  if(path==='/health'){res.writeHead(closing?503:200,{'content-type':'application/json'});res.end(JSON.stringify({ok:!closing,rooms:rooms.size}));return;}
  if(path==='/multiplayer-config.json'){res.writeHead(200,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify({url:process.env.RENDER_EXTERNAL_URL||process.env.PUBLIC_SERVER_URL||'http://'+req.headers.host}));return;}
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);res.end();return;}
  let file;try{file=resolve(root,'.'+decodeURIComponent(path==='/'?'/index.html':path));}catch{res.writeHead(400);res.end();return;}
  if(!file.startsWith(root+'/')){res.writeHead(403);res.end();return;}
  try{if(!(await stat(file)).isFile())throw Error();res.writeHead(200,{'content-type':types[extname(file)]||'application/octet-stream','x-content-type-options':'nosniff','cache-control':extname(file)==='.html'?'no-cache':'public,max-age=3600'});res.end(req.method==='HEAD'?'':await readFile(file));}catch{res.writeHead(404);res.end('Not found');}
 });
 const wss=new WebSocketServer({noServer:true,maxPayload:4096,perMessageDeflate:false});
 const origins=new Set(['https://herosiege.bushyjelly257.chatgpt.site',...(process.env.ALLOWED_ORIGINS||'').split(',').filter(Boolean)]);
 server.on('upgrade',(req,socket,head)=>{const origin=req.headers.origin;const own=origin&&new URL(origin).host===req.headers.host;const local=origin&&/^http:\/\/(localhost|127\.0\.0\.1|terminal\.local)(:\d+)?$/.test(origin);if(closing||req.url!=='/multiplayer'||(origin&&!origins.has(origin)&&!own&&!local)){socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');socket.destroy();return;}wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));});
 const send=(ws,data)=>{if(ws.readyState===WebSocket.OPEN&&ws.bufferedAmount<2_000_000)ws.send(JSON.stringify(data));};
 const roomInfo=room=>({code:room.code,hostId:room.hostId,started:!!room.engine,players:[...room.players.values()].map(p=>({id:p.id,name:p.name,hero:p.hero,connected:p.ws?.readyState===1}))});
 const broadcast=(room,data)=>{for(const p of room.players.values())if(p.ws)send(p.ws,data);};
 const update=room=>{for(const p of room.players.values())if(p.ws)send(p.ws,{type:'room',playerId:p.id,room:roomInfo(room)});};
 function destroy(room){if(room.closed)return;room.closed=true;clearInterval(room.timer);room.engine?.close();rooms.delete(room.code);}
 wss.on('connection',ws=>{
  let room=null,player=null,rate=0,lastRate=Date.now();ws.alive=true;ws.on('pong',()=>ws.alive=true);
  ws.on('message',raw=>{try{
   const now=Date.now();if(now-lastRate>1000){rate=0;lastRate=now;}if(++rate>60){ws.close(1008,'Too many requests');return;}
   const message=JSON.parse(raw);const fail=(message,fatal=false)=>send(ws,{type:'error',message,fatal});
   if(!room){
    if(message.type!=='create'&&message.type!=='join')return fail('Create or join a room first.');
    if(message.type==='create'){if(rooms.size>=12)return fail('The server is full. Please try later.',true);let code;do{code=randomBytes(5).toString('hex').toUpperCase().replace(/[01]/g,'A').slice(0,6);}while(rooms.has(code));room={code,hostId:null,players:new Map(),engine:null,timer:null};rooms.set(code,room);}
    else room=rooms.get(String(message.code||'').toUpperCase());
    if(!room)return fail('Room not found. Check the code.',true);
    if(room.engine||room.players.size>=4){room=null;return fail('This room has already started or is full.',true);}
    const id=randomUUID(),name=String(message.name||'Player').replace(/[\x00-\x1F]/g,'').trim().slice(0,24)||'Player';player={id,name,hero:null,ws};room.players.set(id,player);room.hostId??=id;update(room);return;
   }
   if(message.type==='choose'&&!room.engine&&['ranger','paladin','orc'].includes(message.hero)){player.hero=message.hero;update(room);}
   if(message.type==='start'&&!room.engine){if(room.hostId!==player.id)return fail('Only the host can start.');if([...room.players.values()].some(p=>!p.hero))return fail('Every player must choose a hero.');room.engine=createEngine([...room.players.values()].map(({id,name,hero})=>({id,name,hero})));broadcast(room,{type:'started'});let tick=0;
    room.timer=setInterval(()=>{try{room.engine.step(.04);for(const notice of room.engine.notices()){const target=room.players.get(notice.playerId);if(target?.ws)send(target.ws,{type:'notice',text:notice.text});}if(++tick%2===0)broadcast(room,{type:'state',state:room.engine.snapshot()});}catch(error){console.error('Room simulation failed:',error.message);broadcast(room,{type:'error',message:'The session encountered an error. Please create a new room.',fatal:true});for(const p of room.players.values())p.ws?.close();destroy(room);}},40);
    broadcast(room,{type:'state',state:room.engine.snapshot()});
   }
   if(message.type==='input'&&room.engine&&message.input&&typeof message.input==='object')room.engine.input(player.id,{...message.input,host:room.hostId===player.id});
  }catch(error){send(ws,{type:'error',message:'Unable to process this request.'});console.error('Request failed:',error.message);}});
  ws.on('close',()=>{if(!room||!player||room.closed)return;room.players.delete(player.id);if(!room.players.size){destroy(room);return;}if(room.hostId===player.id)room.hostId=room.players.keys().next().value;if(room.engine){broadcast(room,{type:'error',message:player.name+' left. The session has ended.',fatal:true});for(const p of room.players.values())p.ws?.close();destroy(room);}else update(room);});
  ws.on('error',()=>{});
 });
 const heartbeat=setInterval(()=>{for(const ws of wss.clients){if(!ws.alive){ws.terminate();continue;}ws.alive=false;ws.ping();}},30000);heartbeat.unref();
 return {server,rooms,async close(){closing=true;clearInterval(heartbeat);for(const room of rooms.values())destroy(room);for(const ws of wss.clients)ws.terminate();await new Promise(r=>wss.close(r));await new Promise(r=>server.close(r));}};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){const app=createGameServer();app.server.listen(Number(process.env.PORT)||Number(process.argv[process.argv.indexOf('--port')+1])||10000,'0.0.0.0',()=>console.log('Hero Siege listening'));for(const sig of ['SIGTERM','SIGINT'])process.on(sig,()=>app.close().then(()=>process.exit(0)));}
